const express = require("express");
const router = express.Router();
const userController = require("../controllers/userController");

// Rotas existentes
router.get("/local", userController.getLocalUsers);
router.get("/firebase", userController.getFirebaseUsers);
router.post("/firebase", userController.addFirebaseUser);

// Nova rota: envia todos os usuários do JSON para o Firebase automaticamente
router.post("/push-json", userController.pushUsersToFirebase);

module.exports = router;

