const express = require("express");
const app = express();
const userRoutes = require("./routes/userRoutes");

app.use(express.json()); // permite receber JSON no body
app.use("/users", userRoutes); // todas as rotas em /users

app.get("/", (req, res) => {
  res.send("API rodando! Use /users para acessar os endpoints");
});

app.listen(3000, () => {
  console.log("Servidor rodando em http://localhost:3000");
});

