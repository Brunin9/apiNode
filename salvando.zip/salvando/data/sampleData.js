module.exports = [
  { nome: "Bruno", email: "bruno@email.com" },
  { nome: "Maria", email: "maria@email.com" }
];

